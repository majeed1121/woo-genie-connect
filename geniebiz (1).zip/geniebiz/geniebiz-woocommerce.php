<?php
/**
 * Plugin Name: Genie Business Payment Gateway
 * Plugin URI: https://wordpress.org/plugins/geniebiz-payment-gateway
 * Description: Genie Business Payment Gateway
 * Author: Genie Business Developers
 * Version: 1.0.5
 * Author URI: https://www.geniebusiness.lk
 * Text Domain: geniebiz
 * Domain Path: /languages
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 5.8
 * Tested up to: 6.9
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * WC requires at least: 6.0
 * WC tested up to: 10.8
 */

if (!defined('ABSPATH')) {
    exit;
}

// Make sure WooCommerce is active (covers both single-site and multisite network-activated cases).
if (
    !in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')), true)
    && !(is_multisite() && array_key_exists('woocommerce/woocommerce.php', (array) get_site_option('active_sitewide_plugins', array())))
) {
    return;
}

require_once(__DIR__ . '/vendor/autoload.php');
require_once(__DIR__ . '/inc/geniebiz-api.php');
require_once(__DIR__ . '/inc/webhook-handler.php');

class GenieBusiness_Woocommerce {

    private static $instance;

    public static $BASE_PATH;
    public static $BASE_URL;

    public static function get_instance() {
        if (!(self::$instance instanceof self)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __clone() {
    }

    private function __construct() {
        $this->init_variables();

        // Declare compatibility with WooCommerce features (HPOS + Cart/Checkout Blocks).
        add_action('before_woocommerce_init', array($this, 'declare_wc_feature_compatibility'));

        // Register the block-based checkout payment method integration.
        // IMPORTANT: this must be hooked from `woocommerce_blocks_loaded` (not from the
        // constructor), so the support class is loaded before the registration callback
        // runs. The previous version registered the callback in __construct() but the
        // class lived in inc/wc-gateway-geniebiz.php, which is only required on
        // plugins_loaded:10 — by then the blocks registration hook has already fired,
        // resulting in a "Class WC_Gateway_Geniebiz_Blocks_Support not found" fatal.
        add_action('woocommerce_blocks_loaded', array($this, 'register_blocks_payment_method'));

        // init payment gateway
        add_action('plugins_loaded', array($this, 'init_payment_gateway'));
        add_filter('woocommerce_payment_gateways', array($this, 'woocommerce_payment_gateways'));
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'plugin_action_links'));
        add_action('init', array($this, 'load_text_domain'));
    }

    public function load_text_domain() {
        load_plugin_textdomain('geniebiz', false, dirname(plugin_basename(__FILE__)) . '/languages/');
    }

    /**
     * Declare compatibility with WooCommerce feature flags. Must run on `before_woocommerce_init`.
     */
    public function declare_wc_feature_compatibility() {
        if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
            \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
        }
    }

    /**
     * Register the AbstractPaymentMethodType for the new Cart/Checkout blocks.
     */
    public function register_blocks_payment_method() {
        if (!class_exists('\Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
            return;
        }

        require_once(self::$BASE_PATH . '/inc/blocks/class-wc-gateway-geniebiz-blocks-support.php');

        add_action(
            'woocommerce_blocks_payment_method_type_registration',
            function ($payment_method_registry) {
                $payment_method_registry->register(new WC_Gateway_Geniebiz_Blocks_Support());
            }
        );
    }

    /**
     * Show action links on the plugin screen.
     * @param mixed $links Plugin Action links.
     * @return array
     */
    public function plugin_action_links($links) {
        $action_links = array(
            'settings' => sprintf(
                '<a href="%s" aria-label="%s">%s</a>',
                admin_url('/admin.php?page=wc-settings&tab=checkout&section=geniebiz'),
                esc_attr__('View GenieBusiness settings', 'geniebiz'),
                esc_html__('Settings', 'geniebiz')
            ),
        );

        return array_merge($action_links, $links);
    }

    public function woocommerce_payment_gateways($methods) {
        $methods[] = 'WC_Gateway_GenieBusiness';
        return $methods;
    }

    public function init_payment_gateway() {
        require_once(self::$BASE_PATH . '/inc/wc-gateway-geniebiz.php');
    }

    private function init_variables() {
        self::$BASE_PATH = untrailingslashit(plugin_dir_path(__FILE__));
        self::$BASE_URL = untrailingslashit(plugin_dir_url(__FILE__));
    }

}

GenieBusiness_Woocommerce::get_instance();
