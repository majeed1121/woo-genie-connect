<?php

if (!defined('ABSPATH')) {
    exit;
}

class GenieBusiness_Webhook_Handler {

    private static $instance;

    public static function get_instance() {
        if (!(self::$instance instanceof self)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __clone() {
    }

    private function __construct() {
        // handle payment redirect + webhook
        add_action('template_redirect', array($this, 'template_redirect'));
    }

    public function template_redirect() {
        // Important: do NOT add `wp_verify_nonce` checks against `_wpnonce` /
        // `_wpnonce_wh` on these callbacks. The webhook payload originates from
        // the Genie Business server, and the payment-return redirect comes from
        // the customer's browser via the payment provider — neither has access
        // to a WP nonce. Authenticity is established by the cryptographic
        // `signature` field below, verified against the Genie Business client
        // secret in `validate_signature()`. A WP nonce check here would always
        // fail and orders would never be marked paid.
        $request_uri = isset($_SERVER['REQUEST_URI']) ? esc_url_raw(wp_unslash($_SERVER['REQUEST_URI'])) : '';

        // webhook
        if (preg_match('@^/geniebiz/webhook/?@', $request_uri)) {
            $raw_body = file_get_contents('php://input');
            $body = json_decode($raw_body, true);
            if (!is_array($body)) {
                $body = array();
            }

            if (self::is_debug()) {
                $logger = wc_get_logger();
                $message = sprintf('WEBHOOK: $body = %s', wp_json_encode($body));
                $logger->info($message, WC_Gateway_GenieBusiness::logger_context());
            }

            $order_id = isset($body['localId']) ? absint($body['localId']) : 0;
            $transaction_id = isset($body['transactionId']) ? sanitize_text_field($body['transactionId']) : '';
            $signature = isset($body['signature']) ? sanitize_text_field($body['signature']) : '';

            $this->proceed_payment_callback($order_id, $transaction_id, $signature, true);
            return;
        }

        // payment redirect
        if (preg_match('@^/geniebiz/([0-9]+)@', $request_uri, $matches)) {
            $order_id = isset($matches[1]) && is_numeric($matches[1]) ? intval($matches[1]) : 0;
            $transaction_id = isset($_GET['transactionId']) ? sanitize_text_field(wp_unslash($_GET['transactionId'])) : '';
            $signature = isset($_GET['signature']) ? sanitize_text_field(wp_unslash($_GET['signature'])) : '';
            $this->proceed_payment_callback($order_id, $transaction_id, $signature);
            return;
        }
    }

    /**
     * @param int $order_id
     * @param string $transaction_id
     * @param string $signature
     * @param bool $isWebhook
     */
    private function proceed_payment_callback($order_id, $transaction_id, $signature, $isWebhook = false) {
        $logger = wc_get_logger();
        if (!$order_id || !$transaction_id || !$signature) {
            return;
        }

        $order = wc_get_order($order_id);
        if (!($order instanceof WC_Order)) {
            return;
        }

        $redirectUrl = $order->{self::get_success_destination_page()}();

        // validate signature (this is the authenticity check, replacing the
        // previous WP-nonce check which never matched).
        if (!GenieBusiness_API::get_instance()->validate_signature($order, $signature)) {
            return;
        }

        $transaction = GenieBusiness_API::get_instance()->get_order_transaction($order_id, $transaction_id);

        // not a valid transaction
        if (!$transaction) {
            return;
        }

        // update order status
        $logger->info($transaction->state, WC_Gateway_GenieBusiness::logger_context());
        switch ($transaction->state) {
            // payment is cancelled
            case 'CANCELLED':
                $order->set_transaction_id($transaction_id);
                $order->update_status('failed');
                if (self::is_debug()) {
                    $message = sprintf('ORDER_CANCELLED: $order_id = %s; $transaction = %s', $order_id, $transaction->id);
                    $logger->info($message, WC_Gateway_GenieBusiness::logger_context());
                }
                $redirectUrl = $order->get_checkout_payment_url();
                $logger->info($redirectUrl, WC_Gateway_GenieBusiness::logger_context());
                break;
            // payment is still pending
            case 'QR_CODE_GENERATED':
                if (!$isWebhook) {
                    $order->set_transaction_id($transaction_id);
                    $order->update_status('failed');
                    if (self::is_debug()) {
                        $message = sprintf('ORDER_PENDING: $order_id = %s; $transaction = %s', $order_id, $transaction->id);
                        $logger->info($message, WC_Gateway_GenieBusiness::logger_context());
                    }
                    $redirectUrl = $order->get_checkout_payment_url();
                    $logger->info($redirectUrl, WC_Gateway_GenieBusiness::logger_context());
                    break;
                }
            // payment failed (intentional fall-through above)
            case 'FAILED':
                $order->set_transaction_id($transaction_id);
                $order->update_status('failed');
                if (self::is_debug()) {
                    $message = sprintf('ORDER_FAILED: $order_id = %s; $transaction = %s', $order_id, $transaction->id);
                    $logger->info($message, WC_Gateway_GenieBusiness::logger_context());
                }
                $redirectUrl = $order->get_checkout_payment_url();
                $logger->info($redirectUrl, WC_Gateway_GenieBusiness::logger_context());
                break;
            // payment is completed
            case 'CONFIRMED':
                $order->payment_complete($transaction->id);
                if (self::is_debug()) {
                    $message = sprintf('ORDER_CONFIRMED: $order_id = %s; $transaction = %s', $order_id, $transaction->id);
                    $logger->info($message, WC_Gateway_GenieBusiness::logger_context());
                }
                $logger->info($redirectUrl, WC_Gateway_GenieBusiness::logger_context());
                break;
            // payment authorized
            case 'AUTHORIZED':
                $order->payment_complete($transaction->id);
                if (self::is_debug()) {
                    $message = sprintf('ORDER_AUTHORIZED: $order_id = %s; $transaction = %s', $order_id, $transaction->id);
                    $logger->info($message, WC_Gateway_GenieBusiness::logger_context());
                }
                $logger->info($redirectUrl, WC_Gateway_GenieBusiness::logger_context());
                break;
        }

        // redirect to the view order page
        wp_safe_redirect($redirectUrl);
        exit;
    }

    /**
     * @return bool
     */
    public static function is_debug() {
        $methods = WC_Payment_Gateways::instance()->payment_gateways();

        if (!isset($methods['geniebiz'])) {
            return false;
        }

        /**
         * @var WC_Gateway_GenieBusiness $geniebiz_payment_gateway
         */
        $geniebiz_payment_gateway = $methods['geniebiz'];

        return $geniebiz_payment_gateway->is_debug();
    }

    public static function get_success_destination_page() {
        $methods = WC_Payment_Gateways::instance()->payment_gateways();

        if (!isset($methods['geniebiz'])) {
            return 'get_view_order_url';
        }

        /**
         * @var WC_Gateway_GenieBusiness $geniebiz_payment_gateway
         */
        $geniebiz_payment_gateway = $methods['geniebiz'];

        return $geniebiz_payment_gateway->get_destination_page();
    }
}

GenieBusiness_Webhook_Handler::get_instance();
