<?php

class GenieBusiness_API {

    private static $instance;

    /**
     * @var WC_Gateway_GenieBusiness $gateway
     */
    private static $gateway;

    /**
     * @var \GenieBusinessConnect\Client $client
     */
    private static $client;

    public static function get_instance() {
        if (!(self::$instance instanceof self)) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __clone() {
    }

    private function __construct() {
        $this->get_settings();
        $this->init_client();
    }

    /**
     * @param WC_Order $order
     * @param string $signature
     * @return bool
     */
    public function validate_signature($order, $signature) {
        if (!self::$client) {
            return false;
        }
        return (new \GenieBusinessConnect\Crypt\Verify())->validateSignature(self::$client, $signature, self::amount_in_minor_units($order), $order->get_currency());
    }

    /**
     * The Genie Business API requires an integer amount expressed in the
     * currency's minor units (e.g. cents). Multiplying the WC float total by
     * 100 directly is unsafe — `19.99 * 100` evaluates to `1998.9999999999998`
     * under IEEE 754, which the API rejects with `Provided data is invalid`.
     *
     * @param WC_Order $order
     * @return int
     */
    private static function amount_in_minor_units($order) {
        return (int) round(((float) $order->get_total()) * 100);
    }

    /**
     * @param int $order_id
     * @param string $transaction_id
     * @return null|object
     */
    public function get_order_transaction($order_id, $transaction_id) {
        if (!self::$client) {
            return null;
        }
        try {
            $transaction = self::$client->transactions->get($transaction_id);

            // not the order transaction
            if (!isset($transaction->id) || !isset($transaction->localId) || $transaction->localId != $order_id) {
                return null;
            }

            return $transaction;
        } catch (Exception $ex) {
            return null;
        }
    }

    /**
     * @param WC_Order $order
     * @return WP_Error|object
     */
    public function create_transaction($order) {
        if (!self::$client) {
            return new WP_Error('geniebiz_not_configured', __('Genie Business payment gateway is not configured.', 'geniebiz'));
        }

        $json = array(
            'currency' => $order->get_currency(),
            'amount' => self::amount_in_minor_units($order),
            'localId' => strval($order->get_id()),
            'redirectUrl' => home_url(sprintf('/geniebiz/%s', $order->get_id())),
        );

        if (self::$gateway->is_webhook_enabled()) {
            $json['webhook'] = home_url('/geniebiz/webhook');
        }

        if ($validity = self::$gateway->get_validity()) {
            $json['validForHours'] = $validity;
        }

        if (GenieBusiness_Webhook_Handler::is_debug()) {
            $logger = wc_get_logger();
            $message = sprintf('CREATE_TRANSACTION: $json = %s', wp_json_encode($json));
            $logger->info($message, WC_Gateway_GenieBusiness::logger_context());
        }

        try {
            $transaction = self::$client->transactions->create($json);
            if (!isset($transaction->url) || !$transaction->url) {
                return new WP_Error('unknown_error', 'Unknown error');
            }

            return $transaction;
        } catch (Exception $ex) {
            return new WP_Error($ex->getMessage(), $ex->getMessage());
        }
    }

    private function init_client() {
        if (self::$client instanceof \GenieBusinessConnect\Client) {
            return;
        }

        if (!self::$gateway) {
            return;
        }

        $settings = self::$gateway->settings;

        $sandbox = isset($settings['sandbox']) && 'yes' === $settings['sandbox'];

        $api_id = isset($settings['live_api_id']) ? $settings['live_api_id'] : '';
        $api_key = isset($settings['live_api_key']) ? $settings['live_api_key'] : '';

        if ($sandbox) {
            $api_id = isset($settings['sandbox_api_id']) ? $settings['sandbox_api_id'] : '';
            $api_key = isset($settings['sandbox_api_key']) ? $settings['sandbox_api_key'] : '';
        }

        $mode = $sandbox ? 'sandbox' : 'production';
        self::$client = new \GenieBusinessConnect\Client($api_key, $api_id, $mode);
    }

    private function get_settings() {
        // Use payment_gateways() rather than get_available_payment_gateways() — the latter
        // filters by is_available() (currency/cart context) and would silently drop our
        // gateway during webhook callbacks where no customer session exists.
        $methods = WC_Payment_Gateways::instance()->payment_gateways();

        if (!isset($methods['geniebiz'])) {
            return;
        }

        /**
         * @var WC_Gateway_GenieBusiness $geniebiz_payment_gateway
         */
        self::$gateway = $methods['geniebiz'];
    }
}
