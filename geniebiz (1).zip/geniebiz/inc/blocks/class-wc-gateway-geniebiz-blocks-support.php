<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

/**
 * Exposes the Genie Business payment gateway to the WooCommerce Cart/Checkout
 * Blocks. The gateway is redirect-based, so the block-side experience just
 * mirrors the classic gateway's title/description and defers actual processing
 * to the server-side WC_Gateway_GenieBusiness::process_payment() implementation.
 */
final class WC_Gateway_Geniebiz_Blocks_Support extends AbstractPaymentMethodType {

    protected $name = 'geniebiz';

    public function initialize() {
        $this->settings = get_option('woocommerce_geniebiz_settings', array());
    }

    /**
     * Defer the active check to the live classic gateway. Reading the option
     * directly returns an empty array until the admin has saved the settings
     * screen once, which would silently hide the gateway from the block
     * checkout on a fresh install even though it is enabled by default.
     */
    public function is_active() {
        $gateways = WC()->payment_gateways() ? WC()->payment_gateways()->payment_gateways() : array();
        return isset($gateways['geniebiz']) && 'yes' === $gateways['geniebiz']->enabled;
    }

    public function get_payment_method_script_handles() {
        $handle = 'wc-geniebiz-blocks-integration';
        $asset_file = GenieBusiness_Woocommerce::$BASE_PATH . '/assets/blocks.asset.php';
        $asset = file_exists($asset_file)
            ? require($asset_file)
            : array(
                'dependencies' => array('wp-element', 'wp-i18n', 'wc-blocks-registry', 'wc-settings'),
                'version' => '1.0.5',
            );

        wp_register_script(
            $handle,
            GenieBusiness_Woocommerce::$BASE_URL . '/assets/blocks.js',
            $asset['dependencies'],
            $asset['version'],
            true
        );

        if (function_exists('wp_set_script_translations')) {
            wp_set_script_translations($handle, 'geniebiz', GenieBusiness_Woocommerce::$BASE_PATH . '/languages');
        }

        return array($handle);
    }

    public function get_payment_method_data() {
        $gateways = WC()->payment_gateways() ? WC()->payment_gateways()->payment_gateways() : array();
        $gateway = isset($gateways['geniebiz']) ? $gateways['geniebiz'] : null;

        return array(
            'title'       => $gateway ? $gateway->get_title() : __('Visa / Master / Amex ( Powered by genie business )', 'geniebiz'),
            'description' => $gateway ? $gateway->get_description() : __('Pay securely by Credit or Debit card through genie business.', 'geniebiz'),
            'supports'    => $gateway ? array_filter($gateway->supports, array($gateway, 'supports')) : array('products'),
        );
    }
}
