=== Genie Business Payment Gateway ===
Contributors: geniebusiness
Tags: geniebusiness, geniebiz, payments, payment gateway, ipg sri lanka
Requires at least: 5.8
Tested up to: 6.9
Stable tag: 1.0.5
Requires PHP: 7.4
WC requires at least: 6.0
WC tested up to: 10.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Secure and easy payments in WooCommerce using Genie Business Payment Gateway.

== Description ==

No hassle receiving payments

Genie Business is on a mission to accepting online payments easier and faster. By integrating both credit, debit payments giving you the steppingstones to entering the online marketplace. Offer your customers multiple payment methods in foreign as well as local currency.

= CARD PAYMENT METHODS =

Credit & Debit cards:

* MasterCard
* Visa
* American Express

= MOBILE WALLETS =

* Genie
* ezCash
* Justpay


Create a merchant account on our [merchant dashboard](https://dashboard.geniebiz.lk) and start taking payments today.

> Quick sign-up and no hidden fees. Quicker, Safer & Smarter payments

= FEATURES =

* No-code setup, install the plugin and enter your API keys
* Easy sandbox mode for testing before launching our store
* Configure payment expiry and sync your payment links
* Production testing using test payment gateway
* Get dedicated developer support
* Debug events using the details secure logger
* Offer foreign-currency payments to your customers

== Frequently Asked Questions ==

= Where do I get my API keys? =

Create a merchant account on our [merchant dashboard](https://dashboard.geniebiz.lk)
Once you have an account you can find your production API keys under the "Connect" menu option

= How can I test payments without actually paying? =

You can immediately get setup on production but enable a “test payment provider”. If you’re already close to going live and just want to test the final flows you will be using this. These transactions will go through your production account but won’t actually be paid out. It always you to smoke test your integration with a fake payment provider but using your live credentials. This also means you can see all payments in the dashboard, app etc..

We have a full sandbox which allows you more of a development approach. This allows you to test with multiple payment providers and these transactions won’t show up in your account. You will be given a sandbox API endpoint, client ID and API key from us and you can use these to initiate transactions and integrate in your account.
For sandbox credentials please contact us at genie.integration@dialog.lk

= What is the payment expiry setting? =

You can decide how long you want an initiated payment to be payable by the customer. Once it has expired and has not been completed the order will be automatically cancelled.
If you do not set this value it will take the default configured value from your dashboard settings on Genie Business

= Any other question? =

Please contact us on our  [website](https://dashboard.geniebiz.lk) or email us at genie.integration@dialog.lk

= How can I contribute to the source code or translations? =

Check out our development repository on [Github](http://github.com/PomeloPay/pomelo-woocommerce)

== Screenshots ==

1. The settings screen for your plugin, easily select sandbox or production and add your specific keys.
2. Payment method selection for easy checkout.

== Installation ==

= Minimum Requirements =

* PHP version >= 7.4
* cURL, JSON, bcrypt
* WordPress >= 5.8
* WooCommerce >= 6.0

= Wordpress Plugin installation =

1. Search for Genie Business on Plugins > New Plugin.
2. Activate the plugin in your Wordpress admin > Plugins
3. Enter your sandbox or production client_id and client_secret from Genie Business
4. Enable the plugin in either sandbox or production mode, you're now good to go

= Developer manual installation =

0. Make sure you have SFTP/SSH or Git access to your Wordpress installation directory on your server.
1. Download the plugin package
2. Upload the unzipped folder 'geniebiz-woocommerce' to the `/wp-content/plugins/` directory
3. Enable the Genie Business Payment Gateway plugin through the 'Plugins' menu in WordPress
4. Enter your sandbox or production client_id and client_secret from Genie Business
5. Enable the plugin in either sandbox or production mode, you're now good to go

= Updating =

We will ensure backwards compatibility for minor version update. For major version upgrades (e.g. 1.0.0 to 2.0.0) make sure you have a backup and use our sandbox to test

== Changelog ==

= 1.0.5 - 18-05-2026 =

* **Fixed checkout page crash on WordPress 6.x + WooCommerce 8.x and later.** The block-checkout integration class was registered before its definition was loaded, causing a "Class WC_Gateway_Geniebiz_Blocks_Support not found" fatal on every page that initialised the Cart/Checkout blocks. The class now lives in `inc/blocks/` and is loaded on `woocommerce_blocks_loaded` before the registration hook fires.
* **Fixed payment confirmation never completing.** The webhook + payment-return handler was performing `wp_verify_nonce()` against `_wpnonce` / `_wpnonce_wh` fields that the external payment provider does not supply, so every callback returned early and orders stayed in "on hold" even after a successful payment. Authenticity is now established via the existing cryptographic `validate_signature()` check.
* **Fixed API 400 on amounts with fractional cents** (e.g. 19.99 → 1998.9999999999998 → rejected). The amount is now rounded and cast to an integer in minor units, both for transaction creation and signature validation.
* Compatibility with WordPress 6.9 and WooCommerce 10.8 (HPOS + Blocks compatibility declarations were already present and now actually work).
* Replaced deprecated `new WC_Order()` / `$woocommerce` global with `wc_get_order()` / `WC()` helpers (HPOS-safe).
* Switched gateway lookups from `get_available_payment_gateways()` to `payment_gateways()` so webhook callbacks succeed without a customer session.
* Raised minimum PHP to 7.4 and minimum WooCommerce to 6.0.
* Added `Requires Plugins: woocommerce` header (WordPress 6.5+).

= 1.0.3 - 15-05-2021 =

* Fixed a default setting for sandbox mode

= 1.0.2 - 15-05-2021 =

* NEW Feature, select your destination page after an order is received
* Improved event, redirect handling
* Improved settings description

= 1.0.1 - 15-03-2021 =

* Fixed a bug that would cause the sandbox to be used even when left unchecked

= 1.0.0 - 15-03-2021 =

* NEW Initial release
