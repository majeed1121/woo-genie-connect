const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
const { getSetting } = window.wc.wcSettings;
const { createElement } = window.wp.element;
const { __ } = window.wp.i18n;

const settings = getSetting("geniebiz_data", {});

const Content = () => {
  return createElement(
    "div",
    {},
    settings.description ||
      __("Secure online payments powered by Genie Business", "geniebiz")
  );
};

const Label = () => {
  return createElement(
    "div",
    {},
    settings.title || __("Secure Online Payment Gateway", "geniebiz")
  );
};

const options = {
  name: "geniebiz",
  content: createElement(Content, null),
  edit: createElement(Content, null),
  label: createElement(Label, null),
  canMakePayment: () => true,
  ariaLabel: settings.title || __("Secure Online Payment Gateway", "geniebiz"),
  placeOrderButtonLabel: __("Proceed to payment", "geniebiz"),
  supports: {
    features: settings.supports || [],
  },
};

registerPaymentMethod(options);
