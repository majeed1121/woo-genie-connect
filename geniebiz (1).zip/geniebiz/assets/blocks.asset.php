<?php return array('dependencies' => array('wp-blocks', 'wp-element', 'wp-i18n', 'wc-blocks-registry', 'wc-settings'), 'version' => '1.0.0'); ?>
